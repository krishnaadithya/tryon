#!/usr/bin/env python3
"""
Logs:
  • fitcheck_model  (CatVTON + FashionCLIP)
  • demo/ artefacts (front-end)
Prints both run-ids for easy deployment in HP AI Studio.
"""
import mlflow, pathlib, shutil
from huggingface_hub import snapshot_download
from mlflow_model import CatVTONMLflowModel

def log_model():
    cat = snapshot_download("zhengchong/CatVTON")
    clip = snapshot_download("patrickjohncyh/fashion-clip-v2")
    mlflow.set_experiment("fit-check")
    with mlflow.start_run(run_name="model") as r:
        mlflow.pyfunc.log_model(
            artifact_path="fitcheck_model",
            python_model=CatVTONMLflowModel(),
            artifacts={"catvton_repo": cat, "fashionclip_repo": clip},
            pip_requirements="requirements.txt",
        )
        return r.info.run_id

def log_demo():
    mlflow.set_experiment("fit-check")
    with mlflow.start_run(run_name="demo") as r:
        mlflow.log_artifacts("demo", artifact_path="demo")
        return r.info.run_id

if __name__ == "__main__":
    print("⏳  logging model…"); mid = log_model();  print("✅", mid)
    print("⏳  logging demo… "); did = log_demo();   print("✅", did)
    print("\nDeploy in HP AI Studio:")
    print("  • Run", mid, "→ Deploy › REST/Swagger")
    print("  • Run", did, "→ Deploy › Folder (will serve at /demo/)")
