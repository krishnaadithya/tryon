
Projects live in the [`projects` directory](../../projects) under the root of this repository, but not here.
