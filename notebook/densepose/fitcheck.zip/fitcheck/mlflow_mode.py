import base64, io, json, torch, mlflow.pyfunc, pandas as pd
from PIL import Image
from huggingface_hub import snapshot_download
from transformers import CLIPModel, CLIPProcessor
import torch.nn.functional as F
from model.pipeline import CatVTONPipeline         # already in repo
from utils import init_weight_dtype, resize_and_crop, resize_and_padding

class CatVTONMLflowModel(mlflow.pyfunc.PythonModel):
    """Pyfunc wrapper exposing three modes via /invocations."""

    def load_context(self, ctx):
        dev = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = dev
        self.vton_path  = ctx.artifacts["catvton_repo"]
        self.clip_path  = ctx.artifacts["fashionclip_repo"]

        self.vton = CatVTONPipeline(
            base_ckpt="booksforcharlie/stable-diffusion-inpainting",
            attn_ckpt=self.vton_path,
            attn_ckpt_version="mix",
            weight_dtype=init_weight_dtype("bf16"),
            use_tf32=True, device=dev)

        self.clip  = CLIPModel.from_pretrained(self.clip_path).to(dev)
        self.proc  = CLIPProcessor.from_pretrained(self.clip_path)

    # ---------- helpers ----------
    @staticmethod
    def _b642img(s): return Image.open(io.BytesIO(base64.b64decode(s))).convert("RGB")
    @staticmethod
    def _img2b64(img):
        buf = io.BytesIO(); img.save(buf, format="PNG")
        return base64.b64encode(buf.getvalue()).decode()

    # ---------- predict ----------
    def predict(self, ctx, x: pd.DataFrame):
        row = x.iloc[0].to_dict() if hasattr(x, "iloc") else json.loads(x)

        # 1️⃣  Virtual try-on
        if "person_image" in row and "cloth_image" in row:
            p = resize_and_crop (self._b642img(row["person_image"]), (768,1024))
            c = resize_and_padding(self._b642img(row["cloth_image"]), (768,1024))
            out = self.vton(image=p, condition_image=c, mask=None,
                            num_inference_steps=int(row.get("steps", 50)),
                            guidance_scale  =float(row.get("guidance", 2.5)))[0]
            return [{"result_image": self._img2b64(out)}]

        # 2️⃣  Image → embedding
        if "image" in row:
            t = self.proc(images=self._b642img(row["image"]), return_tensors="pt"
                         ).to(self.device)
            with torch.no_grad():
                vec = F.normalize(self.clip.get_image_features(**t), p=2, dim=1
                                 ).cpu().squeeze()
            return [{"embedding": vec.tolist()}]

        # 3️⃣  Text → embedding
        if "text" in row:
            t = self.proc(text=[row["text"]], return_tensors="pt").to(self.device)
            with torch.no_grad():
                vec = F.normalize(self.clip.get_text_features(**t), p=2, dim=1
                                 ).cpu().squeeze()
            return [{"embedding": vec.tolist()}]

        raise ValueError("Payload must contain person+cloth OR image OR text")
