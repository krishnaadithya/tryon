import asyncio
import os
import uuid
from datetime import datetime
from typing import Optional, List
import torch
from fastapi import FastAPI, File, UploadFile, Form, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import numpy as np
from PIL import Image
import io
import glob
import json
from transformers import CLIPProcessor, CLIPModel
import torch.nn.functional as F

# Add support for additional image formats
try:
    from PIL import ImageFile
    ImageFile.LOAD_TRUNCATED_IMAGES = True
    # Try to add AVIF support
    try:
        import pillow_avif
        print("AVIF support enabled")
    except ImportError:
        print("AVIF support not available - install pillow-avif for AVIF support")
except ImportError:
    pass

# Your existing imports
from model.cloth_masker import AutoMasker, vis_mask
from model.pipeline import CatVTONPipeline
from utils import init_weight_dtype, resize_and_crop, resize_and_padding
from diffusers.image_processor import VaeImageProcessor

app = FastAPI(title="Fit Check - Virtual Try-On", version="1.0.0")

# Enable CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this properly for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files for images
app.mount("/static", StaticFiles(directory="static"), name="static")

class TryOnRequest(BaseModel):
    cloth_type: str = "upper"
    num_inference_steps: int = 50
    guidance_scale: float = 2.5
    seed: int = 42
    show_type: str = "result only"

class TryOnResponse(BaseModel):
    job_id: str
    status: str
    result_url: Optional[str] = None
    error: Optional[str] = None

class WardrobeItem(BaseModel):
    id: str
    name: str
    type: str
    image_url: str
    added_date: str
    description: Optional[str] = ""
    contextual_description: Optional[str] = ""
    tags: Optional[List[str]] = []
    embedding: Optional[List[float]] = []
    text_embedding: Optional[List[float]] = []

class SearchRequest(BaseModel):
    query: str
    max_results: int = 10

# Global variables for models (initialize once)
pipeline = None
automasker = None
mask_processor = None
fashion_clip_model = None
fashion_clip_processor = None

# Job storage (use Redis/database in production)
jobs = {}

@app.on_event("startup")
async def startup_event():
    """Initialize models on startup"""
    global pipeline, automasker, mask_processor, fashion_clip_model, fashion_clip_processor
    
    # Your existing model initialization code
    from huggingface_hub import snapshot_download
    
    repo_path = snapshot_download(repo_id="zhengchong/CatVTON")
    
    pipeline = CatVTONPipeline(
        base_ckpt="booksforcharlie/stable-diffusion-inpainting",
        attn_ckpt=repo_path,
        attn_ckpt_version="mix",
        weight_dtype=init_weight_dtype("bf16"),
        use_tf32=True,
        device='cuda'
    )
    
    mask_processor = VaeImageProcessor(
        vae_scale_factor=8, 
        do_normalize=False, 
        do_binarize=True, 
        do_convert_grayscale=True
    )
    
    automasker = AutoMasker(
        densepose_ckpt=os.path.join(repo_path, "DensePose"),
        schp_ckpt=os.path.join(repo_path, "SCHP"),
        device='cuda'
    )
    
    # Don't load Fashion CLIP model at startup to save memory
    # It will be loaded on-demand when needed
    print("Fashion CLIP model will be loaded on-demand for memory optimization")
    
    # Auto-populate sample wardrobe if empty
    await populate_sample_wardrobe_if_empty()

def load_fashion_clip_model():
    """Load Fashion CLIP model on demand"""
    global fashion_clip_model, fashion_clip_processor
    
    if fashion_clip_model is None or fashion_clip_processor is None:
        print("Loading Fashion CLIP model...")
        fashion_clip_model = CLIPModel.from_pretrained("patrickjohncyh/fashion-clip")
        fashion_clip_processor = CLIPProcessor.from_pretrained("patrickjohncyh/fashion-clip")
        print("Fashion CLIP model loaded successfully!")

def unload_fashion_clip_model():
    """Unload Fashion CLIP model to free memory"""
    global fashion_clip_model, fashion_clip_processor
    
    if fashion_clip_model is not None:
        del fashion_clip_model
        fashion_clip_model = None
    
    if fashion_clip_processor is not None:
        del fashion_clip_processor
        fashion_clip_processor = None
    
    # Force garbage collection to free GPU memory
    import gc
    gc.collect()
    
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    
    print("Fashion CLIP model unloaded to save memory")

def load_and_convert_image(image_path: str) -> Image.Image:
    """Load an image and convert it to RGB, handling various formats including AVIF"""
    try:
        # First try to open the image normally
        image = Image.open(image_path)
        
        # Convert to RGB (handles RGBA, L, etc.)
        if image.mode != 'RGB':
            # For images with transparency, create white background
            if image.mode in ('RGBA', 'LA'):
                background = Image.new('RGB', image.size, (255, 255, 255))
                if image.mode == 'RGBA':
                    background.paste(image, mask=image.split()[-1])  # Use alpha channel as mask
                else:
                    background.paste(image, mask=image.split()[-1])  # Use alpha channel as mask
                image = background
            else:
                image = image.convert('RGB')
        
        return image
        
    except Exception as e:
        print(f"Error loading image {image_path}: {e}")
        raise HTTPException(status_code=400, detail=f"Cannot load image file: {str(e)}")

def validate_and_convert_upload(content: bytes, filename: str) -> Image.Image:
    """Validate and convert uploaded image content to RGB format"""
    try:
        # Try to open the image from bytes
        image = Image.open(io.BytesIO(content))
        
        # Convert to RGB (handles RGBA, L, etc.)
        if image.mode != 'RGB':
            # For images with transparency, create white background
            if image.mode in ('RGBA', 'LA'):
                background = Image.new('RGB', image.size, (255, 255, 255))
                if image.mode == 'RGBA':
                    background.paste(image, mask=image.split()[-1])  # Use alpha channel as mask
                else:
                    background.paste(image, mask=image.split()[-1])  # Use alpha channel as mask
                image = background
            else:
                image = image.convert('RGB')
        
        return image
        
    except Exception as e:
        print(f"Error processing uploaded image {filename}: {e}")
        raise HTTPException(status_code=400, detail=f"Cannot process image file {filename}. Supported formats: JPG, PNG, WEBP, AVIF")

def generate_image_embedding(image: Image.Image) -> List[float]:
    """Generate embedding for image using Fashion CLIP"""
    global fashion_clip_model, fashion_clip_processor
    
    # Load model on demand
    load_fashion_clip_model()
    
    inputs = fashion_clip_processor(images=image, return_tensors="pt", padding=True)
    with torch.no_grad():
        image_features = fashion_clip_model.get_image_features(**inputs)
        # Normalize the features
        image_features = F.normalize(image_features, p=2, dim=1)
    return image_features.squeeze().tolist()

def generate_simple_description(analysis: dict) -> str:
    """Generate simple, search-friendly description focusing on visual features"""
    # Extract key visual elements
    color = analysis.get("color", "")
    category = analysis.get("category", "")
    pattern = analysis.get("pattern", "")
    
    # Create simple description: "color category" or "pattern category"
    if pattern and pattern != "plain" and pattern != "solid":
        return f"{pattern} {category}".strip()
    else:
        return f"{color} {category}".strip()

def generate_contextual_description(analysis: dict) -> str:
    """Generate rich description including occasion and style context"""
    color = analysis.get("color", "")
    category = analysis.get("category", "")
    pattern = analysis.get("pattern", "")
    occasion = analysis.get("occasion", "")
    style = analysis.get("style", "")
    
    # Build a contextual description
    base_desc = f"{color} {category}".strip()
    
    if pattern and pattern not in ["plain", "solid"]:
        base_desc = f"{pattern} {color} {category}".strip()
    
    # Add style and occasion context
    context_parts = []
    if style and style != "simple":
        context_parts.append(style)
    if occasion and occasion != "casual":
        context_parts.append(f"suitable for {occasion}")
    
    if context_parts:
        return f"{base_desc} - {' and '.join(context_parts)}"
    else:
        return base_desc

def analyze_clothing_image(image: Image.Image) -> dict:
    """Analyze clothing image using Fashion CLIP to extract semantic information"""
    global fashion_clip_model, fashion_clip_processor
    
    # Load model on demand
    load_fashion_clip_model()
    
    # Simplified prompts for better color/visual matching
    category_prompts = [
        "t-shirt", "shirt", "hoodie", "sweatshirt", "pullover", "tank top", 
        "dress", "skirt", "jeans", "pants", "jacket", "blazer", "coat", 
        "sweater", "blouse", "suit"
    ]
    
    color_prompts = [
        "red", "blue", "black", "white", "green", "yellow", "gray", "grey",
        "brown", "pink", "purple", "orange", "beige", "navy", "maroon"
    ]
    
    pattern_prompts = [
        "plain", "striped", "floral", "checkered", "dotted", "geometric", 
        "solid", "printed"
    ]
    
    # Enhanced occasion/style prompts for contextual understanding
    occasion_prompts = [
        "casual", "formal", "business", "party", "wedding", "beach", "sports",
        "evening", "cocktail", "office", "weekend", "vacation", "dinner",
        "traditional", "ethnic", "festive", "ceremony"
    ]
    
    style_prompts = [
        "elegant", "trendy", "vintage", "bohemian", "minimalist", "classic",
        "modern", "chic", "sophisticated", "relaxed", "luxury", "simple"
    ]
    
    def predict_best_prompt(image, prompts):
        inputs = fashion_clip_processor(text=prompts, images=[image], return_tensors="pt", padding=True)
        with torch.no_grad():
            outputs = fashion_clip_model(**inputs)
            logits_per_image = outputs.logits_per_image
            probs = logits_per_image.softmax(dim=1).squeeze().tolist()
        best_idx = torch.tensor(probs).argmax().item()
        return prompts[best_idx], probs[best_idx]
    
    # Analyze different attributes
    category, cat_score = predict_best_prompt(image, category_prompts)
    color, color_score = predict_best_prompt(image, color_prompts)
    pattern, pattern_score = predict_best_prompt(image, pattern_prompts)
    occasion, occasion_score = predict_best_prompt(image, occasion_prompts)
    style, style_score = predict_best_prompt(image, style_prompts)
    
    return {
        "category": category,
        "color": color,
        "pattern": pattern,
        "occasion": occasion,
        "style": style,
        "scores": {
            "category": cat_score,
            "color": color_score,
            "pattern": pattern_score,
            "occasion": occasion_score,
            "style": style_score
        }
    }

def generate_text_embedding(text: str) -> List[float]:
    """Generate embedding for text using Fashion CLIP"""
    global fashion_clip_model, fashion_clip_processor
    
    # Load model on demand
    load_fashion_clip_model()
    
    inputs = fashion_clip_processor(text=[text], return_tensors="pt", padding=True)
    with torch.no_grad():
        text_features = fashion_clip_model.get_text_features(**inputs)
        # Normalize the features
        text_features = F.normalize(text_features, p=2, dim=1)
    return text_features.squeeze().tolist()

def search_wardrobe_semantic(query: str, wardrobe_items: List[dict], max_results: int = 10) -> List[dict]:
    """Hybrid search using both visual and contextual similarity"""
    if not wardrobe_items:
        return []
    
    # Generate query embedding
    query_embedding = generate_text_embedding(query)
    query_tensor = torch.tensor(query_embedding).unsqueeze(0)
    
    # Determine if query is visual-focused or occasion-focused
    visual_keywords = ["color", "pattern", "striped", "floral", "red", "blue", "black", "white", "green", "yellow", "gray", "brown", "pink", "purple", "orange", "navy", "checkered", "dotted"]
    occasion_keywords = ["wedding", "beach", "party", "formal", "casual", "business", "dinner", "office", "vacation", "ceremony", "traditional", "ethnic", "festive", "cocktail", "evening"]
    
    query_lower = query.lower()
    is_visual_query = any(keyword in query_lower for keyword in visual_keywords)
    is_occasion_query = any(keyword in query_lower for keyword in occasion_keywords)
    
    results = []
    for item in wardrobe_items:
        visual_score = 0
        contextual_score = 0
        
        # Calculate visual similarity (text-to-image)
        if item.get('embedding'):
            item_embedding = torch.tensor(item['embedding']).unsqueeze(0)
            visual_score = F.cosine_similarity(query_tensor, item_embedding).item()
        
        # Calculate contextual similarity (text-to-text for occasions)
        if item.get('text_embedding'):
            item_text_embedding = torch.tensor(item['text_embedding']).unsqueeze(0)
            contextual_score = F.cosine_similarity(query_tensor, item_text_embedding).item()
        
        # Weight the scores based on query type
        if is_occasion_query and not is_visual_query:
            # Pure occasion query: prioritize contextual matching
            final_score = contextual_score * 0.8 + visual_score * 0.2
        elif is_visual_query and not is_occasion_query:
            # Pure visual query: prioritize image matching
            final_score = visual_score * 0.8 + contextual_score * 0.2
        else:
            # Mixed or neutral query: balanced approach
            final_score = visual_score * 0.6 + contextual_score * 0.4
        
        # Add small boost for exact tag/description matches
        text_boost = 0
        if item.get('contextual_description'):
            if any(word.lower() in item['contextual_description'].lower() for word in query.lower().split()):
                text_boost += 0.05
        if item.get('tags'):
            if any(word.lower() in ' '.join(item['tags']).lower() for word in query.lower().split()):
                text_boost += 0.05
        
        final_score += text_boost
        
        results.append({
            **item,
            'similarity_score': final_score,
            'visual_score': visual_score,
            'contextual_score': contextual_score,
            'query_type': 'occasion' if is_occasion_query and not is_visual_query else 'visual' if is_visual_query and not is_occasion_query else 'mixed'
        })
    
    # Sort by final similarity score (descending order)
    results.sort(key=lambda x: x['similarity_score'], reverse=True)
    return results[:max_results]

@app.get("/", response_class=HTMLResponse)
async def get_homepage():
    """Serve the main Fit Check interface"""
    with open("templates/index.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

@app.post("/api/upload-wardrobe")
async def upload_wardrobe_item(
    file: UploadFile = File(...),
    name: str = Form(...),
    item_type: str = Form(...),
    custom_description: str = Form("")
):
    """Upload a clothing item to wardrobe with semantic analysis"""
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    # Generate unique filename
    file_extension = file.filename.split(".")[-1]
    unique_filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = f"static/wardrobe/{unique_filename}"
    
    # Create wardrobe directory if it doesn't exist
    os.makedirs("static/wardrobe", exist_ok=True)
    
    # Save file
    content = await file.read()
    with open(file_path, "wb") as buffer:
        buffer.write(content)
    
    # Analyze the image for semantic information
    try:
        # Validate and convert the uploaded image
        image = validate_and_convert_upload(content, file.filename)
        analysis = analyze_clothing_image(image)
        
        # Generate descriptions
        if custom_description.strip():
            description = custom_description
            contextual_description = custom_description
        else:
            description = generate_simple_description(analysis)
            contextual_description = generate_contextual_description(analysis)
        
        # Generate comprehensive tags from analysis
        tags = [
            analysis.get("category", item_type), 
            analysis.get("color", ""), 
            analysis.get("pattern", ""),
            analysis.get("occasion", ""),
            analysis.get("style", "")
        ]
        tags = [tag for tag in tags if tag and tag != "simple"]  # Remove empty tags and generic "simple"
        
        # Generate both image embedding and contextual text embedding
        image_embedding = generate_image_embedding(image)
        text_embedding = generate_text_embedding(contextual_description)
        
    except Exception as e:
        print(f"Error analyzing image: {e}")
        description = custom_description if custom_description.strip() else f"{name}"
        contextual_description = description
        tags = [item_type]
        # For fallback, try to load image and generate embedding
        try:
            image = validate_and_convert_upload(content, file.filename)
            image_embedding = generate_image_embedding(image)
            text_embedding = generate_text_embedding(description)
        except:
            # Last resort: use text embedding of name for both
            image_embedding = generate_text_embedding(description)
            text_embedding = generate_text_embedding(description)
    
    # Create wardrobe item
    item = WardrobeItem(
        id=str(uuid.uuid4()),
        name=name,
        type=item_type,
        image_url=f"/static/wardrobe/{unique_filename}",
        added_date=datetime.now().isoformat(),
        description=description,
        contextual_description=contextual_description,
        tags=tags,
        embedding=image_embedding,
        text_embedding=text_embedding
    )
    
    # Save to wardrobe.json (in production, use a proper database)
    wardrobe_file = "static/wardrobe.json"
    wardrobe = []
    if os.path.exists(wardrobe_file):
        try:
            with open(wardrobe_file, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    wardrobe = json.loads(content)
        except:
            wardrobe = []
    
    wardrobe.append(item.model_dump())
    with open(wardrobe_file, "w", encoding="utf-8") as f:
        json.dump(wardrobe, f, indent=2)
    
    # Unload CLIP model to save memory after processing
    unload_fashion_clip_model()
    
    return {"success": True, "item": item, "analysis": analysis}

@app.get("/api/wardrobe")
async def get_wardrobe():
    """Get all wardrobe items"""
    wardrobe_file = "static/wardrobe.json"
    if not os.path.exists(wardrobe_file):
        return {"items": []}
    
    try:
        with open(wardrobe_file, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                return {"items": []}
            wardrobe = json.loads(content)
    except (json.JSONDecodeError, UnicodeDecodeError):
        # If file is corrupted, return empty and recreate
        with open(wardrobe_file, "w", encoding="utf-8") as f:
            json.dump([], f)
        return {"items": []}
    
    return {"items": wardrobe}

@app.post("/api/search-wardrobe")
async def search_wardrobe(request: SearchRequest):
    """Search wardrobe using semantic similarity"""
    wardrobe_file = "static/wardrobe.json"
    if not os.path.exists(wardrobe_file):
        return {"results": [], "query": request.query}
    
    try:
        with open(wardrobe_file, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                return {"results": [], "query": request.query}
            wardrobe = json.loads(content)
    except:
        return {"results": [], "query": request.query}
    
    # Perform semantic search
    results = search_wardrobe_semantic(request.query, wardrobe, request.max_results)
    
    return {
        "results": results,
        "query": request.query,
        "total_found": len(results)
    }

@app.post("/api/populate-samples")
async def populate_sample_wardrobe():
    """Create empty wardrobe if needed - users will upload their own images"""
    wardrobe_file = "static/wardrobe.json"
    
    # Create empty wardrobe file if it doesn't exist
    if not os.path.exists(wardrobe_file):
        os.makedirs("static", exist_ok=True)
        with open(wardrobe_file, "w", encoding="utf-8") as f:
            json.dump([], f, indent=2)
        return {"success": True, "message": "Empty wardrobe created - ready for your uploads!"}
    
    return {"success": True, "message": "Wardrobe already exists"}

@app.post("/api/regenerate-embeddings") 
async def regenerate_embeddings():
    """Regenerate embeddings for all wardrobe items using IMAGE embeddings"""
    wardrobe_file = "static/wardrobe.json"
    
    if not os.path.exists(wardrobe_file):
        return {"success": False, "message": "No wardrobe found"}
    
    try:
        with open(wardrobe_file, "r", encoding="utf-8") as f:
            content = f.read().strip()
            if not content:
                return {"success": False, "message": "Empty wardrobe"}
            wardrobe = json.loads(content)
    except:
        return {"success": False, "message": "Error reading wardrobe"}
    
    updated_count = 0
    errors = []
    
    # No predefined simple descriptions - all items will be analyzed with AI
    
    for item in wardrobe:
        try:
            # Load image from file path
            image_url = item.get('image_url', '')
            
            # Convert URL to file path
            if image_url.startswith('/static/'):
                image_path = image_url[1:]  # Remove leading slash  
            else:
                image_path = image_url
                
            if os.path.exists(image_path):
                # Load and analyze image
                image = load_and_convert_image(image_path)
                
                # Analyze the image for contextual information
                analysis = analyze_clothing_image(image)
                
                # Generate new image embedding
                image_embedding = generate_image_embedding(image)
                item['embedding'] = image_embedding
                
                # Use AI analysis for description and tags
                item['description'] = generate_simple_description(analysis)
                item['tags'] = [
                    analysis.get("category", item.get('type', 'clothing')),
                    analysis.get("color", ""),
                    analysis.get("pattern", ""),
                    analysis.get("occasion", ""),
                    analysis.get("style", "")
                ]
                item['tags'] = [tag for tag in item['tags'] if tag and tag != "simple"]
                
                # Generate contextual description and text embedding
                item['contextual_description'] = generate_contextual_description(analysis)
                text_embedding = generate_text_embedding(item['contextual_description'])
                item['text_embedding'] = text_embedding
                
                updated_count += 1
                print(f"Updated embedding for: {item.get('name', 'Unknown')}")
                
            else:
                errors.append(f"Image not found: {image_path}")
                
        except Exception as e:
            error_msg = f"Error processing {item.get('name', 'Unknown')}: {str(e)}"
            errors.append(error_msg)
            print(error_msg)
    
    # Save updated wardrobe
    try:
        with open(wardrobe_file, "w", encoding="utf-8") as f:
            json.dump(wardrobe, f, indent=2)
    except Exception as e:
        return {"success": False, "message": f"Error saving wardrobe: {str(e)}"}
    
    # Unload CLIP model to save memory after processing
    unload_fashion_clip_model()
    
    return {
        "success": True, 
        "updated": updated_count,
        "errors": errors,
        "message": f"Updated {updated_count} items with image embeddings"
    }

async def populate_sample_wardrobe_if_empty():
    """Create empty wardrobe if it doesn't exist and ensure existing items have embeddings"""
    wardrobe_file = "static/wardrobe.json"
    
    # Check if wardrobe exists and has items
    wardrobe = []
    if os.path.exists(wardrobe_file):
        try:
            with open(wardrobe_file, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    wardrobe = json.loads(content)
        except:
            wardrobe = []
    
    # If wardrobe doesn't exist, create empty one
    if not os.path.exists(wardrobe_file):
        os.makedirs("static", exist_ok=True)
        with open(wardrobe_file, "w", encoding="utf-8") as f:
            json.dump([], f, indent=2)
        print("Empty wardrobe created - ready for uploads!")
    elif wardrobe:
        # Check if existing items need embeddings
        needs_embeddings = any(
            not item.get("embedding") or not item.get("description") 
            for item in wardrobe
        )
        if needs_embeddings:
            print("Updating existing wardrobe items with embeddings...")
            await regenerate_embeddings()
            print("Embeddings updated successfully!")
            # Model will be unloaded automatically by regenerate_embeddings

@app.delete("/api/wardrobe/{item_id}")
async def delete_wardrobe_item(item_id: str):
    """Delete a wardrobe item"""
    wardrobe_file = "static/wardrobe.json"
    if not os.path.exists(wardrobe_file):
        raise HTTPException(status_code=404, detail="Item not found")
    
    with open(wardrobe_file, "r") as f:
        wardrobe = json.load(f)
    
    # Find and remove item
    item_to_remove = None
    updated_wardrobe = []
    for item in wardrobe:
        if item["id"] == item_id:
            item_to_remove = item
        else:
            updated_wardrobe.append(item)
    
    if item_to_remove is None:
        raise HTTPException(status_code=404, detail="Item not found")
    
    # Delete image file
    image_path = item_to_remove["image_url"].replace("/static/", "static/")
    if os.path.exists(image_path):
        os.remove(image_path)
    
    # Save updated wardrobe
    with open(wardrobe_file, "w") as f:
        json.dump(updated_wardrobe, f)
    
    return {"success": True}

async def process_tryon(
    job_id: str,
    person_image: Image.Image,
    cloth_image: Image.Image,
    mask: Optional[Image.Image],
    request: TryOnRequest
):
    """Background task for processing try-on"""
    try:
        jobs[job_id]["status"] = "processing"
        
        # Resize images
        person_image = resize_and_crop(person_image, (768, 1024))
        cloth_image = resize_and_padding(cloth_image, (768, 1024))
        
        # Process mask
        if mask is not None:
            mask = resize_and_crop(mask, (768, 1024))
        else:
            mask = automasker(person_image, request.cloth_type)['mask']
        
        mask = mask_processor.blur(mask, blur_factor=9)
        
        # Generate result
        generator = None
        if request.seed != -1:
            generator = torch.Generator(device='cuda').manual_seed(request.seed)
        
        result_image = pipeline(
            image=person_image,
            condition_image=cloth_image,
            mask=mask,
            num_inference_steps=request.num_inference_steps,
            guidance_scale=request.guidance_scale,
            generator=generator
        )[0]
        
        # Save result
        result_filename = f"{job_id}_result.png"
        result_path = f"static/results/{result_filename}"
        os.makedirs("static/results", exist_ok=True)
        
        # Save just the result image (no collage)
        final_image = result_image
        final_image.save(result_path)
        
        jobs[job_id].update({
            "status": "completed",
            "result_url": f"/static/results/{result_filename}"
        })
        
    except Exception as e:
        import traceback
        error_detail = f"Try-on processing error: {str(e)}\n{traceback.format_exc()}"
        print(error_detail)
        jobs[job_id].update({
            "status": "failed",
            "error": str(e)
        })

@app.post("/api/tryon", response_model=TryOnResponse)
async def create_tryon(
    background_tasks: BackgroundTasks,
    person_image: UploadFile = File(...),
    cloth_image: UploadFile = File(...),
    mask_image: Optional[UploadFile] = File(None),
    cloth_type: str = Form("upper"),
    num_inference_steps: int = Form(50),
    guidance_scale: float = Form(2.5),
    seed: int = Form(42),
    show_type: str = Form("result only")
):
    """Create a new try-on job"""
    job_id = str(uuid.uuid4())
    
    # Validate inputs
    if not person_image or not cloth_image:
        raise HTTPException(status_code=400, detail="Person and cloth images are required")
    
    try:
        # Load images
        person_content = await person_image.read()
        person_img = validate_and_convert_upload(person_content, person_image.filename)
        
        cloth_content = await cloth_image.read()
        cloth_img = validate_and_convert_upload(cloth_content, cloth_image.filename)
        
        mask_img = None
        if mask_image:
            mask_img = Image.open(io.BytesIO(await mask_image.read())).convert("L")
        
        # Create job
        request = TryOnRequest(
            cloth_type=cloth_type,
            num_inference_steps=num_inference_steps,
            guidance_scale=guidance_scale,
            seed=seed,
            show_type=show_type
        )
        
        jobs[job_id] = {"status": "queued"}
        
        # Start background processing
        background_tasks.add_task(
            process_tryon, job_id, person_img, cloth_img, mask_img, request
        )
        
        return TryOnResponse(job_id=job_id, status="queued")
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing images: {str(e)}")

@app.post("/api/tryon-wardrobe")
async def create_tryon_from_wardrobe(
    background_tasks: BackgroundTasks,
    person_image: UploadFile = File(...),
    wardrobe_item_id: str = Form(...),
    mask_image: Optional[UploadFile] = File(None),
    cloth_type: str = Form("upper"),
    num_inference_steps: int = Form(50),
    guidance_scale: float = Form(2.5),
    seed: int = Form(42),
    show_type: str = Form("result only")
):
    """Create a try-on job using a wardrobe item"""
    job_id = str(uuid.uuid4())
    
    try:
        print(f"Starting try-on job {job_id} with wardrobe item {wardrobe_item_id}")
        # Get wardrobe item
        wardrobe_file = "static/wardrobe.json"
        if not os.path.exists(wardrobe_file):
            raise HTTPException(status_code=404, detail="Wardrobe not found")
        
        with open(wardrobe_file, "r") as f:
            wardrobe = json.load(f)
        
        wardrobe_item = None
        for item in wardrobe:
            if item["id"] == wardrobe_item_id:
                wardrobe_item = item
                break
        
        if wardrobe_item is None:
            raise HTTPException(status_code=404, detail="Wardrobe item not found")
        
        # Load images
        person_content = await person_image.read()
        person_img = validate_and_convert_upload(person_content, person_image.filename)
        
        cloth_img_path = wardrobe_item["image_url"]
        if cloth_img_path.startswith("/static/"):
            cloth_img_path = cloth_img_path.replace("/static/", "static/")
        
        # Use the new image loading function that handles AVIF and other formats
        cloth_img = load_and_convert_image(cloth_img_path)
        
        mask_img = None
        if mask_image:
            mask_img = Image.open(io.BytesIO(await mask_image.read())).convert("L")
        
        # Use the wardrobe item's type for cloth_type
        actual_cloth_type = wardrobe_item.get("type", cloth_type)
        
        # Create job
        request = TryOnRequest(
            cloth_type=actual_cloth_type,
            num_inference_steps=num_inference_steps,
            guidance_scale=guidance_scale,
            seed=seed,
            show_type=show_type
        )
        
        jobs[job_id] = {"status": "queued"}
        
        # Start background processing
        background_tasks.add_task(
            process_tryon, job_id, person_img, cloth_img, mask_img, request
        )
        
        return TryOnResponse(job_id=job_id, status="queued")
        
    except Exception as e:
        import traceback
        error_detail = f"Try-on wardrobe setup error: {str(e)}\n{traceback.format_exc()}"
        print(error_detail)
        raise HTTPException(status_code=500, detail=error_detail)

@app.get("/api/tryon/{job_id}", response_model=TryOnResponse)
async def get_tryon_status(job_id: str):
    """Get the status of a try-on job"""
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    
    job = jobs[job_id]
    return TryOnResponse(
        job_id=job_id,
        status=job["status"],
        result_url=job.get("result_url"),
        error=job.get("error")
    )

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "models_loaded": pipeline is not None}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)